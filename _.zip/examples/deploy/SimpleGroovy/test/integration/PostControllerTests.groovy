class PostControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
