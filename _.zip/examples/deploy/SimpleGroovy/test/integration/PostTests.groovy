class PostTests extends GroovyTestCase {

    void testSomething() {

    }
}
