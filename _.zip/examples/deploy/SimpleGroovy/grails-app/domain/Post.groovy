class Post {
    static mapping = {
        table 'posts'
    }
    
    String title
    String body
    boolean published
}
