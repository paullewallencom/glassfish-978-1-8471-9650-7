class PostController {

   def scaffold = Post
}
