package com.programmingstuff.hello;

import java.util.Date;

public class HelloProvider {
    public String getName() {
        return "Hello Provider at " + new Date();
    }

}
